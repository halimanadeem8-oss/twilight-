from django.core.management.base import BaseCommand
from django.utils.text import slugify
from store.models import Product

DEMO_PRODUCTS = [
    ("Twilight Sparkle Acrylic Keychain", "Twilight's Magic", "A purple Twilight Sparkle charm with a playful star-shaped detail.", 550, "💜", "store/images/twilight-keychain.jpg"),
    ("Pastel Charm Safety Pins", "Princess Collection", "A set of pastel safety pins decorated with delicate gold-tone charms.", 450, "✨", "store/images/cute-pins.jpg"),
    ("Twilight Beaded Bag Charm", "Twilight's Magic", "A purple and pink beaded charm with a Twilight Sparkle pendant.", 650, "🌙", "store/images/twilight-beaded-charm.jpg"),
    ("Colourful Heart Keychain", "Cute & Pastel", "A cheerful keychain with colourful beads, hearts, and star charms.", 400, "💗", "store/images/colourful-keychain.jpg"),
    ("Pastel Star Safety Pin Pair", "Cute & Pastel", "Cute pastel star charms on safety pins, perfect for decorating a bag.", 350, "⭐", "store/images/star-pin-pair.jpg"),
    ("Celestial Star Earrings", "Celestial Designs", "Dangling star earrings with purple beads and a celestial feel.", 380, "🌟", "store/images/star-earrings.jpg"),
]

class Command(BaseCommand):
    help = "Add or update the sample products for the Twilight Pins demo store."

    def handle(self, *args, **options):
        for name, category, description, price, emoji, image_path in DEMO_PRODUCTS:
            slug = slugify(name)
            Product.objects.update_or_create(
                slug=slug,
                defaults={"name": name, "category": category, "description": description,
                          "price": price, "emoji": emoji, "image_path": image_path,
                          "is_featured": True, "is_available": True},
            )
        self.stdout.write(self.style.SUCCESS("Demo products added/updated with your photos. Edit them in /admin/."))
