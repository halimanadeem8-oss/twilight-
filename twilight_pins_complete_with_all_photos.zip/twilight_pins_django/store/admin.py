from django.contrib import admin
from .models import Product

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "price", "category", "is_featured", "is_available")
    list_filter = ("category", "is_featured", "is_available")
    search_fields = ("name", "description")
    prepopulated_fields = {"slug": ("name",)}
