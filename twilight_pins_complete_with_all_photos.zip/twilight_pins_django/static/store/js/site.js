// Small, progressive enhancement for the demo storefront.
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".product-card").forEach((card, index) => {
    card.style.setProperty("--card-delay", `${index * 55}ms`);
  });
});
